<?php

/**
Plugin Name: Footer Scripts
 */
add_action('wp_footer', 'my_footer_scripts');
function my_footer_scripts()
{
  ?>
  <script>
    AOS.init({
      duration: 500,
      delay: 200,
    });
  </script>
<?php
}
